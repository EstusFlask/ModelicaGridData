within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00087
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 59.2789888,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 49.4086318,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 2.5315860,

// Bus: 'B05' (PQ bus)
V5 = 1.0000906,
A5 = 52.7745035,

// Bus: 'B06' (PQ bus)
V6 = 0.9625242,
A6 = 42.5146253,

// Bus: 'B07' (PQ bus)
V7 = 0.9330256,
A7 = 33.7893049,

// Bus: 'B08' (PQ bus)
V8 = 0.8927443,
A8 = 11.7428009,

// Bus: 'B09' (PQ bus)
V9 = 0.9667186,
A9 = -9.3771213,

// Bus: 'B10' (PQ bus)
V10 = 0.9887733,
A10 = -4.1785512,

// Bus: 'B11' (PQ bus)
V11 = 1.0149011,
A11 = -1.6816259

);
end PF_Bus_best_00087;