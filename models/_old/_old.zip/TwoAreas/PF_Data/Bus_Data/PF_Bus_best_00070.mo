within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00070
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 43.2800688,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 33.4696023,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -3.8418667,

// Bus: 'B05' (PQ bus)
V5 = 1.0036590,
A5 = 36.7988082,

// Bus: 'B06' (PQ bus)
V6 = 0.9712756,
A6 = 26.6380097,

// Bus: 'B07' (PQ bus)
V7 = 0.9487176,
A7 = 18.0927636,

// Bus: 'B08' (PQ bus)
V8 = 0.9249948,
A8 = 0.0852161,

// Bus: 'B09' (PQ bus)
V9 = 0.9728048,
A9 = -17.3408157,

// Bus: 'B10' (PQ bus)
V10 = 0.9892043,
A10 = -10.5490666,

// Bus: 'B11' (PQ bus)
V11 = 1.0142992,
A11 = -4.1605935

);
end PF_Bus_best_00070;