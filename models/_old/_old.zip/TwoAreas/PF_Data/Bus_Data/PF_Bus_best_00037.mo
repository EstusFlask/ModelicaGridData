within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00037
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -79.8540592,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = -89.4251421,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 9.5410780,

// Bus: 'B05' (PQ bus)
V5 = 0.9827506,
A5 = -86.2887275,

// Bus: 'B06' (PQ bus)
V6 = 0.9184369,
A6 = 83.5523941,

// Bus: 'B07' (PQ bus)
V7 = 0.8517434,
A7 = 74.3505604,

// Bus: 'B08' (PQ bus)
V8 = 0.7017430,
A8 = 35.1130149,

// Bus: 'B09' (PQ bus)
V9 = 0.8948250,
A9 = -1.1960190,

// Bus: 'B10' (PQ bus)
V10 = 0.9504855,
A10 = 2.5610253,

// Bus: 'B11' (PQ bus)
V11 = 0.9973026,
A11 = 0.8616433

);
end PF_Bus_best_00037;