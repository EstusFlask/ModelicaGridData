within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00039
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -81.6357558,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 88.2427183,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 7.4565248,

// Bus: 'B05' (PQ bus)
V5 = 0.9806029,
A5 = -88.2407267,

// Bus: 'B06' (PQ bus)
V6 = 0.9145374,
A6 = 81.0175451,

// Bus: 'B07' (PQ bus)
V7 = 0.8469046,
A7 = 71.2488986,

// Bus: 'B08' (PQ bus)
V8 = 0.6975417,
A8 = 32.4136053,

// Bus: 'B09' (PQ bus)
V9 = 0.8925813,
A9 = -3.8867508,

// Bus: 'B10' (PQ bus)
V10 = 0.9491499,
A10 = 0.4650751,

// Bus: 'B11' (PQ bus)
V11 = 0.9978045,
A11 = 0.0647667

);
end PF_Bus_best_00039;