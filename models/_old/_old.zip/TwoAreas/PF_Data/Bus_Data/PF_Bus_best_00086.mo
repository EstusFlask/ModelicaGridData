within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00086
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 69.3562724,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 59.4279883,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 5.4899449,

// Bus: 'B05' (PQ bus)
V5 = 0.9967014,
A5 = 62.8295727,

// Bus: 'B06' (PQ bus)
V6 = 0.9542157,
A6 = 52.4736597,

// Bus: 'B07' (PQ bus)
V7 = 0.9181438,
A7 = 43.5704923,

// Bus: 'B08' (PQ bus)
V8 = 0.8605000,
A8 = 18.3204613,

// Bus: 'B09' (PQ bus)
V9 = 0.9554987,
A9 = -5.7578998,

// Bus: 'B10' (PQ bus)
V10 = 0.9832850,
A10 = -1.2578189,

// Bus: 'B11' (PQ bus)
V11 = 1.0120692,
A11 = -0.5512807

);
end PF_Bus_best_00086;