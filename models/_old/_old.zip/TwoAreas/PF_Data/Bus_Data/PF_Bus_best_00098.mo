within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00098
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 70.2573672,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 60.3100096,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 4.7063033,

// Bus: 'B05' (PQ bus)
V5 = 0.9955985,
A5 = 63.7234059,

// Bus: 'B06' (PQ bus)
V6 = 0.9515129,
A6 = 53.3358287,

// Bus: 'B07' (PQ bus)
V7 = 0.9133061,
A7 = 44.3732997,

// Bus: 'B08' (PQ bus)
V8 = 0.8496143,
A8 = 18.1788842,

// Bus: 'B09' (PQ bus)
V9 = 0.9506084,
A9 = -6.7949577,

// Bus: 'B10' (PQ bus)
V10 = 0.9804840,
A10 = -2.0608272,

// Bus: 'B11' (PQ bus)
V11 = 1.0111895,
A11 = -0.8650352

);
end PF_Bus_best_00098;