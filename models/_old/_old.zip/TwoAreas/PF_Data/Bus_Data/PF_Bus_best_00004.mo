within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00004
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -79.4551565,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = -89.3836354,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 9.3685475,

// Bus: 'B05' (PQ bus)
V5 = 0.9813513,
A5 = -86.0005524,

// Bus: 'B06' (PQ bus)
V6 = 0.9158819,
A6 = 83.4620979,

// Bus: 'B07' (PQ bus)
V7 = 0.8485440,
A7 = 73.8921599,

// Bus: 'B08' (PQ bus)
V8 = 0.6989464,
A8 = 34.8828823,

// Bus: 'B09' (PQ bus)
V9 = 0.8937268,
A9 = -1.4299502,

// Bus: 'B10' (PQ bus)
V10 = 0.9498359,
A10 = 2.3827428,

// Bus: 'B11' (PQ bus)
V11 = 0.9971155,
A11 = 0.7928443

);
end PF_Bus_best_00004;