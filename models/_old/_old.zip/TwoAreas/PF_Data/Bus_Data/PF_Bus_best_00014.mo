within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00014
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -84.4571116,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 85.5196308,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 5.4573586,

// Bus: 'B05' (PQ bus)
V5 = 0.9810382,
A5 = 88.9682870,

// Bus: 'B06' (PQ bus)
V6 = 0.9153555,
A6 = 78.3312560,

// Bus: 'B07' (PQ bus)
V7 = 0.8479788,
A7 = 68.6663324,

// Bus: 'B08' (PQ bus)
V8 = 0.6982967,
A8 = 29.8419431,

// Bus: 'B09' (PQ bus)
V9 = 0.8917507,
A9 = -6.4544027,

// Bus: 'B10' (PQ bus)
V10 = 0.9484735,
A10 = -1.5391042,

// Bus: 'B11' (PQ bus)
V11 = 0.9982867,
A11 = -0.6959073

);
end PF_Bus_best_00014;