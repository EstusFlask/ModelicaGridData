within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00009
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 79.2917865,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 69.2557878,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 5.1882000,

// Bus: 'B05' (PQ bus)
V5 = 0.9905558,
A5 = 72.7244166,

// Bus: 'B06' (PQ bus)
V6 = 0.9391601,
A6 = 62.1894108,

// Bus: 'B07' (PQ bus)
V7 = 0.8912197,
A7 = 52.9457004,

// Bus: 'B08' (PQ bus)
V8 = 0.8002630,
A8 = 22.5075680,

// Bus: 'B09' (PQ bus)
V9 = 0.9310538,
A9 = -6.3813464,

// Bus: 'B10' (PQ bus)
V10 = 0.9698825,
A10 = -1.6532518,

// Bus: 'B11' (PQ bus)
V11 = 1.0068443,
A11 = -0.7177669

);
end PF_Bus_best_00009;