within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00094
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 41.6719153,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 31.8728200,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -3.8973598,

// Bus: 'B05' (PQ bus)
V5 = 1.0043440,
A5 = 35.1950942,

// Bus: 'B06' (PQ bus)
V6 = 0.9729561,
A6 = 25.0530830,

// Bus: 'B07' (PQ bus)
V7 = 0.9517328,
A7 = 16.5415962,

// Bus: 'B08' (PQ bus)
V8 = 0.9315832,
A8 = -0.6955164,

// Bus: 'B09' (PQ bus)
V9 = 0.9755157,
A9 = -17.3787513,

// Bus: 'B10' (PQ bus)
V10 = 0.9906611,
A10 = -10.5946515,

// Bus: 'B11' (PQ bus)
V11 = 1.0148639,
A11 = -4.1800365

);
end PF_Bus_best_00094;