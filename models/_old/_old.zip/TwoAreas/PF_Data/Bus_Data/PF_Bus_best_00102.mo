within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00102
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 61.3880721,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 51.4888554,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 1.7424453,

// Bus: 'B05' (PQ bus)
V5 = 0.9983946,
A5 = 54.8724891,

// Bus: 'B06' (PQ bus)
V6 = 0.9583659,
A6 = 44.5647905,

// Bus: 'B07' (PQ bus)
V7 = 0.9255755,
A7 = 35.7513216,

// Bus: 'B08' (PQ bus)
V8 = 0.8760887,
A8 = 12.1536690,

// Bus: 'B09' (PQ bus)
V9 = 0.9591304,
A9 = -10.4511246,

// Bus: 'B10' (PQ bus)
V10 = 0.9843706,
A10 = -4.9978428,

// Bus: 'B11' (PQ bus)
V11 = 1.0132102,
A11 = -2.0011608

);
end PF_Bus_best_00102;