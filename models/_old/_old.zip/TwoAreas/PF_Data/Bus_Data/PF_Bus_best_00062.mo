within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00062
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -77.6964389,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = -87.4829446,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 10.9029009,

// Bus: 'B05' (PQ bus)
V5 = 0.9818874,
A5 = -84.1979386,

// Bus: 'B06' (PQ bus)
V6 = 0.9168428,
A6 = 85.4148409,

// Bus: 'B07' (PQ bus)
V7 = 0.8497104,
A7 = 75.9903216,

// Bus: 'B08' (PQ bus)
V8 = 0.6998383,
A8 = 36.8612198,

// Bus: 'B09' (PQ bus)
V9 = 0.8942477,
A9 = 0.5346946,

// Bus: 'B10' (PQ bus)
V10 = 0.9500268,
A10 = 3.9191450,

// Bus: 'B11' (PQ bus)
V11 = 0.9962293,
A11 = 1.3753996

);
end PF_Bus_best_00062;