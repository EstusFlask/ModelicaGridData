within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00105
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 54.4011455,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 44.5422141,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -0.1269695,

// Bus: 'B05' (PQ bus)
V5 = 1.0007663,
A5 = 47.9010705,

// Bus: 'B06' (PQ bus)
V6 = 0.9641809,
A6 = 37.6601109,

// Bus: 'B07' (PQ bus)
V7 = 0.9359950,
A7 = 28.9694404,

// Bus: 'B08' (PQ bus)
V8 = 0.8984890,
A8 = 7.7081503,

// Bus: 'B09' (PQ bus)
V9 = 0.9665098,
A9 = -12.7305130,

// Bus: 'B10' (PQ bus)
V10 = 0.9876971,
A10 = -6.8444515,

// Bus: 'B11' (PQ bus)
V11 = 1.0145103,
A11 = -2.7186255

);
end PF_Bus_best_00105;