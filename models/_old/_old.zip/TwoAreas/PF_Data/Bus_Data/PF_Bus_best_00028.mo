within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00028
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -77.9186444,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = -87.8963561,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 10.4766550,

// Bus: 'B05' (PQ bus)
V5 = 0.9811338,
A5 = -84.4792803,

// Bus: 'B06' (PQ bus)
V6 = 0.9154716,
A6 = 84.9309279,

// Bus: 'B07' (PQ bus)
V7 = 0.8480024,
A7 = 75.3090781,

// Bus: 'B08' (PQ bus)
V8 = 0.6984017,
A8 = 36.3076879,

// Bus: 'B09' (PQ bus)
V9 = 0.8936823,
A9 = -0.0161930,

// Bus: 'B10' (PQ bus)
V10 = 0.9497328,
A10 = 3.4900779,

// Bus: 'B11' (PQ bus)
V11 = 0.9963842,
A11 = 1.2122339

);
end PF_Bus_best_00028;