within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00027
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -77.7892810,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = -87.7766615,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 10.5627531,

// Bus: 'B05' (PQ bus)
V5 = 0.9810934,
A5 = -84.3529059,

// Bus: 'B06' (PQ bus)
V6 = 0.9153967,
A6 = 85.0470294,

// Bus: 'B07' (PQ bus)
V7 = 0.8479063,
A7 = 75.4150854,

// Bus: 'B08' (PQ bus)
V8 = 0.6983108,
A8 = 36.4182097,

// Bus: 'B09' (PQ bus)
V9 = 0.8936546,
A9 = 0.0933131,

// Bus: 'B10' (PQ bus)
V10 = 0.9497080,
A10 = 3.5759721,

// Bus: 'B11' (PQ bus)
V11 = 0.9963166,
A11 = 1.2447182

);
end PF_Bus_best_00027;