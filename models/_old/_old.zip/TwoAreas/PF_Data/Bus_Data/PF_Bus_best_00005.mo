within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00005
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -80.1448265,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 89.8940767,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 8.7999023,

// Bus: 'B05' (PQ bus)
V5 = 0.9812305,
A5 = -86.7002928,

// Bus: 'B06' (PQ bus)
V6 = 0.9156680,
A6 = 82.7278939,

// Bus: 'B07' (PQ bus)
V7 = 0.8482897,
A7 = 73.1246519,

// Bus: 'B08' (PQ bus)
V8 = 0.6987452,
A8 = 34.1498039,

// Bus: 'B09' (PQ bus)
V9 = 0.8935126,
A9 = -2.1587507,

// Bus: 'B10' (PQ bus)
V10 = 0.9497253,
A10 = 1.8131344,

// Bus: 'B11' (PQ bus)
V11 = 0.9973871,
A11 = 0.5767323

);
end PF_Bus_best_00005;