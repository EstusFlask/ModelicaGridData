within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00019
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 40.6952428,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 30.8880812,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -5.3384839,

// Bus: 'B05' (PQ bus)
V5 = 1.0038578,
A5 = 34.2152715,

// Bus: 'B06' (PQ bus)
V6 = 0.9717634,
A6 = 24.0599342,

// Bus: 'B07' (PQ bus)
V7 = 0.9495928,
A7 = 15.5245140,

// Bus: 'B08' (PQ bus)
V8 = 0.9262188,
A8 = -2.1228060,

// Bus: 'B09' (PQ bus)
V9 = 0.9709693,
A9 = -19.2481393,

// Bus: 'B10' (PQ bus)
V10 = 0.9872100,
A10 = -12.0592957,

// Bus: 'B11' (PQ bus)
V11 = 1.0128837,
A11 = -4.7449530

);
end PF_Bus_best_00019;