within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00036
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -80.5607593,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 89.8500371,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 8.9779390,

// Bus: 'B05' (PQ bus)
V5 = 0.9826913,
A5 = -87.0010389,

// Bus: 'B06' (PQ bus)
V6 = 0.9183352,
A6 = 82.8210287,

// Bus: 'B07' (PQ bus)
V7 = 0.8516300,
A7 = 73.6010535,

// Bus: 'B08' (PQ bus)
V8 = 0.7016657,
A8 = 34.3882487,

// Bus: 'B09' (PQ bus)
V9 = 0.8946704,
A9 = -1.9170100,

// Bus: 'B10' (PQ bus)
V10 = 0.9504151,
A10 = 1.9971707,

// Bus: 'B11' (PQ bus)
V11 = 0.9975959,
A11 = 0.6477106

);
end PF_Bus_best_00036;