within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00064
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 62.1139647,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 52.2112160,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 2.0045514,

// Bus: 'B05' (PQ bus)
V5 = 0.9981880,
A5 = 55.5970277,

// Bus: 'B06' (PQ bus)
V6 = 0.9578596,
A6 = 45.2834731,

// Bus: 'B07' (PQ bus)
V7 = 0.9246686,
A7 = 36.4591541,

// Bus: 'B08' (PQ bus)
V8 = 0.8741581,
A8 = 12.6611322,

// Bus: 'B09' (PQ bus)
V9 = 0.9585755,
A9 = -10.1260616,

// Bus: 'B10' (PQ bus)
V10 = 0.9841533,
A10 = -4.7372314,

// Bus: 'B11' (PQ bus)
V11 = 1.0131073,
A11 = -1.9000853

);
end PF_Bus_best_00064;