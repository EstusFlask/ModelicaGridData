within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00063
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -80.8270519,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 88.9487693,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 7.9342054,

// Bus: 'B05' (PQ bus)
V5 = 0.9801717,
A5 = -87.4636725,

// Bus: 'B06' (PQ bus)
V6 = 0.9137449,
A6 = 81.6855042,

// Bus: 'B07' (PQ bus)
V7 = 0.8458993,
A7 = 71.8095457,

// Bus: 'B08' (PQ bus)
V8 = 0.6967003,
A8 = 33.0242250,

// Bus: 'B09' (PQ bus)
V9 = 0.8924629,
A9 = -3.2777008,

// Bus: 'B10' (PQ bus)
V10 = 0.9490945,
A10 = 0.9421693,

// Bus: 'B11' (PQ bus)
V11 = 0.9975538,
A11 = 0.2455488

);
end PF_Bus_best_00063;