within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00023
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 72.7757082,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 62.8116773,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 5.3784218,

// Bus: 'B05' (PQ bus)
V5 = 0.9946396,
A5 = 66.2354205,

// Bus: 'B06' (PQ bus)
V6 = 0.9491633,
A6 = 55.8201464,

// Bus: 'B07' (PQ bus)
V7 = 0.9091022,
A7 = 46.8053970,

// Bus: 'B08' (PQ bus)
V8 = 0.8403845,
A8 = 19.7676385,

// Bus: 'B09' (PQ bus)
V9 = 0.9472674,
A9 = -5.9784764,

// Bus: 'B10' (PQ bus)
V10 = 0.9787724,
A10 = -1.4005980,

// Bus: 'B11' (PQ bus)
V11 = 1.0103145,
A11 = -0.6113313

);
end PF_Bus_best_00023;