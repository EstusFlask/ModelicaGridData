within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00035
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -81.2883217,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 88.9812397,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 8.2364963,

// Bus: 'B05' (PQ bus)
V5 = 0.9821561,
A5 = -87.7723899,

// Bus: 'B06' (PQ bus)
V6 = 0.9173657,
A6 = 81.9003363,

// Bus: 'B07' (PQ bus)
V7 = 0.8504326,
A7 = 72.5357712,

// Bus: 'B08' (PQ bus)
V8 = 0.7006170,
A8 = 33.4312475,

// Bus: 'B09' (PQ bus)
V9 = 0.8940475,
A9 = -2.8718418,

// Bus: 'B10' (PQ bus)
V10 = 0.9500490,
A10 = 1.2525346,

// Bus: 'B11' (PQ bus)
V11 = 0.9978284,
A11 = 0.3647089

);
end PF_Bus_best_00035;