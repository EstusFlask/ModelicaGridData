within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00049
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 76.4309716,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 66.4386013,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 6.0983551,

// Bus: 'B05' (PQ bus)
V5 = 0.9930209,
A5 = 69.8799759,

// Bus: 'B06' (PQ bus)
V6 = 0.9451976,
A6 = 59.4175891,

// Bus: 'B07' (PQ bus)
V7 = 0.9020098,
A7 = 50.3133725,

// Bus: 'B08' (PQ bus)
V8 = 0.8246689,
A8 = 21.8904154,

// Bus: 'B09' (PQ bus)
V9 = 0.9413159,
A9 = -5.1260392,

// Bus: 'B10' (PQ bus)
V10 = 0.9756191,
A10 = -0.7026784,

// Bus: 'B11' (PQ bus)
V11 = 1.0088195,
A11 = -0.3454117

);
end PF_Bus_best_00049;