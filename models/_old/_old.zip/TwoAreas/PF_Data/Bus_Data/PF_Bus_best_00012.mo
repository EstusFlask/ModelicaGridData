within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00012
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -82.6325672,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 87.4825648,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 7.0136484,

// Bus: 'B05' (PQ bus)
V5 = 0.9815675,
A5 = -89.1644251,

// Bus: 'B06' (PQ bus)
V6 = 0.9163043,
A6 = 80.3449534,

// Bus: 'B07' (PQ bus)
V7 = 0.8491313,
A7 = 70.8220523,

// Bus: 'B08' (PQ bus)
V8 = 0.6994406,
A8 = 31.8523858,

// Bus: 'B09' (PQ bus)
V9 = 0.8930914,
A9 = -4.4466919,

// Bus: 'B10' (PQ bus)
V10 = 0.9494325,
A10 = 0.0246350,

// Bus: 'B11' (PQ bus)
V11 = 0.9981271,
A11 = -0.1018564

);
end PF_Bus_best_00012;