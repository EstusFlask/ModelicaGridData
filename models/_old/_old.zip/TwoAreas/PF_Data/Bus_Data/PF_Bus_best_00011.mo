within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00011
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -82.7428880,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 87.3104662,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 6.8490506,

// Bus: 'B05' (PQ bus)
V5 = 0.9813230,
A5 = -89.2938466,

// Bus: 'B06' (PQ bus)
V6 = 0.9158596,
A6 = 80.1500765,

// Bus: 'B07' (PQ bus)
V7 = 0.8485776,
A7 = 70.5634010,

// Bus: 'B08' (PQ bus)
V8 = 0.6989493,
A8 = 31.6382006,

// Bus: 'B09' (PQ bus)
V9 = 0.8928232,
A9 = -4.6604826,

// Bus: 'B10' (PQ bus)
V10 = 0.9492605,
A10 = -0.1413504,

// Bus: 'B11' (PQ bus)
V11 = 0.9981200,
A11 = -0.1650248

);
end PF_Bus_best_00011;