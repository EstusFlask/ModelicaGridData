within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00068
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 32.1001271,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 22.3199055,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -8.5590805,

// Bus: 'B05' (PQ bus)
V5 = 1.0054863,
A5 = 25.6306960,

// Bus: 'B06' (PQ bus)
V6 = 0.9757588,
A6 = 15.5198500,

// Bus: 'B07' (PQ bus)
V7 = 0.9567629,
A7 = 7.0640953,

// Bus: 'B08' (PQ bus)
V8 = 0.9402502,
A8 = -8.2961678,

// Bus: 'B09' (PQ bus)
V9 = 0.9711205,
A9 = -23.3022156,

// Bus: 'B10' (PQ bus)
V10 = 0.9847899,
A10 = -15.2964849,

// Bus: 'B11' (PQ bus)
V11 = 1.0100303,
A11 = -5.9960484

);
end PF_Bus_best_00068;