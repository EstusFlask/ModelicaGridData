within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00029
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -78.8053737,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = -88.8639786,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 9.6911384,

// Bus: 'B05' (PQ bus)
V5 = 0.9808206,
A5 = -85.3909745,

// Bus: 'B06' (PQ bus)
V6 = 0.9149090,
A6 = 83.9335928,

// Bus: 'B07' (PQ bus)
V7 = 0.8473165,
A7 = 74.2284772,

// Bus: 'B08' (PQ bus)
V8 = 0.6978729,
A8 = 35.2937794,

// Bus: 'B09' (PQ bus)
V9 = 0.8933853,
A9 = -1.0223803,

// Bus: 'B10' (PQ bus)
V10 = 0.9496149,
A10 = 2.7033939,

// Bus: 'B11' (PQ bus)
V11 = 0.9968260,
A11 = 0.9139460

);
end PF_Bus_best_00029;