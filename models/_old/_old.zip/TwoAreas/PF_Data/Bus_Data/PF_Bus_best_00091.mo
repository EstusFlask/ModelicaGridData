within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00091
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 27.8409969,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 18.0755108,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -9.8163592,

// Bus: 'B05' (PQ bus)
V5 = 1.0063829,
A5 = 21.3773539,

// Bus: 'B06' (PQ bus)
V6 = 0.9779588,
A6 = 11.2908245,

// Bus: 'B07' (PQ bus)
V7 = 0.9607125,
A7 = 2.8783227,

// Bus: 'B08' (PQ bus)
V8 = 0.9481817,
A8 = -11.1411459,

// Bus: 'B09' (PQ bus)
V9 = 0.9719714,
A9 = -24.8730893,

// Bus: 'B10' (PQ bus)
V10 = 0.9841424,
A10 = -16.5582170,

// Bus: 'B11' (PQ bus)
V11 = 1.0088298,
A11 = -6.4830095

);
end PF_Bus_best_00091;