within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00041
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 46.8965221,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 37.0640018,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -3.2756588,

// Bus: 'B05' (PQ bus)
V5 = 1.0023373,
A5 = 40.4066786,

// Bus: 'B06' (PQ bus)
V6 = 0.9680336,
A6 = 30.2094207,

// Bus: 'B07' (PQ bus)
V7 = 0.9429026,
A7 = 21.5983100,

// Bus: 'B08' (PQ bus)
V8 = 0.9124682,
A8 = 2.1332396,

// Bus: 'B09' (PQ bus)
V9 = 0.9683375,
A9 = -16.6799687,

// Bus: 'B10' (PQ bus)
V10 = 0.9870902,
A10 = -9.9972899,

// Bus: 'B11' (PQ bus)
V11 = 1.0136407,
A11 = -3.9437508

);
end PF_Bus_best_00041;