within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00048
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 67.7235312,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 57.7975192,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 4.4161320,

// Bus: 'B05' (PQ bus)
V5 = 0.9968332,
A5 = 61.1976983,

// Bus: 'B06' (PQ bus)
V6 = 0.9545388,
A6 = 50.8455558,

// Bus: 'B07' (PQ bus)
V7 = 0.9187222,
A7 = 41.9494331,

// Bus: 'B08' (PQ bus)
V8 = 0.8615801,
A8 = 16.8455433,

// Bus: 'B09' (PQ bus)
V9 = 0.9552990,
A9 = -7.1149661,

// Bus: 'B10' (PQ bus)
V10 = 0.9829917,
A10 = -2.3336547,

// Bus: 'B11' (PQ bus)
V11 = 1.0122606,
A11 = -0.9685723

);
end PF_Bus_best_00048;