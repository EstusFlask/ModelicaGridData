within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00075
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 70.3510976,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 60.4052431,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 4.8928273,

// Bus: 'B05' (PQ bus)
V5 = 0.9956852,
A5 = 63.8177077,

// Bus: 'B06' (PQ bus)
V6 = 0.9517253,
A6 = 53.4326265,

// Bus: 'B07' (PQ bus)
V7 = 0.9136863,
A7 = 44.4747898,

// Bus: 'B08' (PQ bus)
V8 = 0.8504963,
A8 = 18.3503679,

// Bus: 'B09' (PQ bus)
V9 = 0.9510830,
A9 = -6.5546228,

// Bus: 'B10' (PQ bus)
V10 = 0.9807773,
A10 = -1.8722707,

// Bus: 'B11' (PQ bus)
V11 = 1.0112550,
A11 = -0.7917936

);
end PF_Bus_best_00075;