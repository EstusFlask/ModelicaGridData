within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00006
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -81.7018841,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 88.1959373,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 7.4318990,

// Bus: 'B05' (PQ bus)
V5 = 0.9806825,
A5 = -88.3008863,

// Bus: 'B06' (PQ bus)
V6 = 0.9146830,
A6 = 80.9779251,

// Bus: 'B07' (PQ bus)
V7 = 0.8470878,
A7 = 71.2294165,

// Bus: 'B08' (PQ bus)
V8 = 0.6976974,
A8 = 32.3827270,

// Bus: 'B09' (PQ bus)
V9 = 0.8926288,
A9 = -3.9176442,

// Bus: 'B10' (PQ bus)
V10 = 0.9491773,
A10 = 0.4406842,

// Bus: 'B11' (PQ bus)
V11 = 0.9978280,
A11 = 0.0555579

);
end PF_Bus_best_00006;