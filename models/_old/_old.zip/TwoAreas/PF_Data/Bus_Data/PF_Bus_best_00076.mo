within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00076
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 70.2913218,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 60.3439996,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 4.7350060,

// Bus: 'B05' (PQ bus)
V5 = 0.9956005,
A5 = 63.7573740,

// Bus: 'B06' (PQ bus)
V6 = 0.9515179,
A6 = 53.3698557,

// Bus: 'B07' (PQ bus)
V7 = 0.9133151,
A7 = 44.4074374,

// Bus: 'B08' (PQ bus)
V8 = 0.8496400,
A8 = 18.2139792,

// Bus: 'B09' (PQ bus)
V9 = 0.9506369,
A9 = -6.7584099,

// Bus: 'B10' (PQ bus)
V10 = 0.9805050,
A10 = -2.0319793,

// Bus: 'B11' (PQ bus)
V11 = 1.0111902,
A11 = -0.8538526

);
end PF_Bus_best_00076;