within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00017
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 47.8301456,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 37.9903548,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -3.2454654,

// Bus: 'B05' (PQ bus)
V5 = 1.0019035,
A5 = 41.3374804,

// Bus: 'B06' (PQ bus)
V6 = 0.9669698,
A6 = 31.1281964,

// Bus: 'B07' (PQ bus)
V7 = 0.9409949,
A7 = 22.4952588,

// Bus: 'B08' (PQ bus)
V8 = 0.9082841,
A8 = 2.5815422,

// Bus: 'B09' (PQ bus)
V9 = 0.9666151,
A9 = -16.6621796,

// Bus: 'B10' (PQ bus)
V10 = 0.9861610,
A10 = -9.9734598,

// Bus: 'B11' (PQ bus)
V11 = 1.0132773,
A11 = -3.9335373

);
end PF_Bus_best_00017;