within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00084
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 74.7543757,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 64.7843086,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 6.4524828,

// Bus: 'B05' (PQ bus)
V5 = 0.9942937,
A5 = 68.2118024,

// Bus: 'B06' (PQ bus)
V6 = 0.9483157,
A6 = 57.7864974,

// Bus: 'B07' (PQ bus)
V7 = 0.9075860,
A7 = 48.7527667,

// Bus: 'B08' (PQ bus)
V8 = 0.8371795,
A8 = 21.3960891,

// Bus: 'B09' (PQ bus)
V9 = 0.9465176,
A9 = -4.6283440,

// Bus: 'B10' (PQ bus)
V10 = 0.9784970,
A10 = -0.3284540,

// Bus: 'B11' (PQ bus)
V11 = 1.0098254,
A11 = -0.1973126

);
end PF_Bus_best_00084;