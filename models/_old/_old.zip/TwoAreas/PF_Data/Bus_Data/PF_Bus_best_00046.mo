within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00046
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 49.8056832,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 39.9712517,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -1.3557686,

// Bus: 'B05' (PQ bus)
V5 = 1.0022232,
A5 = 43.3150976,

// Bus: 'B06' (PQ bus)
V6 = 0.9677538,
A6 = 33.1146787,

// Bus: 'B07' (PQ bus)
V7 = 0.9424007,
A7 = 24.4978358,

// Bus: 'B08' (PQ bus)
V8 = 0.9121392,
A8 = 4.7728087,

// Bus: 'B09' (PQ bus)
V9 = 0.9707773,
A9 = -14.2322272,

// Bus: 'B10' (PQ bus)
V10 = 0.9894715,
A10 = -8.0611489,

// Bus: 'B11' (PQ bus)
V11 = 1.0150631,
A11 = -3.1927018

);
end PF_Bus_best_00046;