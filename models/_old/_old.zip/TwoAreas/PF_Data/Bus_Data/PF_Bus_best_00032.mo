within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00032
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 63.9315367,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 54.0122682,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 2.0689365,

// Bus: 'B05' (PQ bus)
V5 = 0.9972249,
A5 = 57.4082785,

// Bus: 'B06' (PQ bus)
V6 = 0.9554989,
A6 = 47.0673252,

// Bus: 'B07' (PQ bus)
V7 = 0.9204412,
A7 = 38.1920778,

// Bus: 'B08' (PQ bus)
V8 = 0.8648137,
A8 = 13.5221529,

// Bus: 'B09' (PQ bus)
V9 = 0.9547860,
A9 = -10.0846703,

// Bus: 'B10' (PQ bus)
V10 = 0.9820990,
A10 = -4.6870141,

// Bus: 'B11' (PQ bus)
V11 = 1.0122832,
A11 = -1.8811097

);
end PF_Bus_best_00032;