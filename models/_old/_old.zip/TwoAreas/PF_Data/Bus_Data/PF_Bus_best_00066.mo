within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00066
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 30.4663062,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 20.6875436,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -9.4828792,

// Bus: 'B05' (PQ bus)
V5 = 1.0055749,
A5 = 23.9974475,

// Bus: 'B06' (PQ bus)
V6 = 0.9759762,
A6 = 13.8890097,

// Bus: 'B07' (PQ bus)
V7 = 0.9571531,
A7 = 5.4375478,

// Bus: 'B08' (PQ bus)
V8 = 0.9405638,
A8 = -9.6838964,

// Bus: 'B09' (PQ bus)
V9 = 0.9693793,
A9 = -24.4883631,

// Bus: 'B10' (PQ bus)
V10 = 0.9830129,
A10 = -16.2325198,

// Bus: 'B11' (PQ bus)
V11 = 1.0086361,
A11 = -6.3540705

);
end PF_Bus_best_00066;