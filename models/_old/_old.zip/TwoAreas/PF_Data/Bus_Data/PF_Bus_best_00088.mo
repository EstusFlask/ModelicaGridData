within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00088
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 47.9935496,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 38.1708993,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -1.6057881,

// Bus: 'B05' (PQ bus)
V5 = 1.0029277,
A5 = 41.5075429,

// Bus: 'B06' (PQ bus)
V6 = 0.9694817,
A6 = 31.3266056,

// Bus: 'B07' (PQ bus)
V7 = 0.9454997,
A7 = 22.7450357,

// Bus: 'B08' (PQ bus)
V8 = 0.9188498,
A8 = 3.7718929,

// Bus: 'B09' (PQ bus)
V9 = 0.9732868,
A9 = -14.5191257,

// Bus: 'B10' (PQ bus)
V10 = 0.9907246,
A10 = -8.3026488,

// Bus: 'B11' (PQ bus)
V11 = 1.0155195,
A11 = -3.2874786

);
end PF_Bus_best_00088;