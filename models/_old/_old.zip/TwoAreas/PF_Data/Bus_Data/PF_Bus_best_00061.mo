within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00061
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -77.1821452,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = -86.7974145,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 11.5280002,

// Bus: 'B05' (PQ bus)
V5 = 0.9825432,
A5 = -83.6305782,

// Bus: 'B06' (PQ bus)
V6 = 0.9180338,
A6 = 86.1633693,

// Bus: 'B07' (PQ bus)
V7 = 0.8511873,
A7 = 76.9145739,

// Bus: 'B08' (PQ bus)
V8 = 0.7010563,
A8 = 37.6682802,

// Bus: 'B09' (PQ bus)
V9 = 0.8947075,
A9 = 1.3377813,

// Bus: 'B10' (PQ bus)
V10 = 0.9502219,
A10 = 4.5463876,

// Bus: 'B11' (PQ bus)
V11 = 0.9958761,
A11 = 1.6134152

);
end PF_Bus_best_00061;