within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00052
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 82.4689387,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 72.4244000,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 7.0432160,

// Bus: 'B05' (PQ bus)
V5 = 0.9900771,
A5 = 75.8983791,

// Bus: 'B06' (PQ bus)
V6 = 0.9379878,
A6 = 65.3491461,

// Bus: 'B07' (PQ bus)
V7 = 0.8891257,
A7 = 56.0778787,

// Bus: 'B08' (PQ bus)
V8 = 0.7958574,
A8 = 25.2097934,

// Bus: 'B09' (PQ bus)
V9 = 0.9302630,
A9 = -4.0364082,

// Bus: 'B10' (PQ bus)
V10 = 0.9696749,
A10 = 0.2002921,

// Bus: 'B11' (PQ bus)
V11 = 1.0060908,
A11 = -0.0057183

);
end PF_Bus_best_00052;