within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00016
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 62.0361536,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 52.1190773,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 0.8211565,

// Bus: 'B05' (PQ bus)
V5 = 0.9973525,
A5 = 55.5137331,

// Bus: 'B06' (PQ bus)
V6 = 0.9558115,
A6 = 45.1764164,

// Bus: 'B07' (PQ bus)
V7 = 0.9210008,
A7 = 36.3079442,

// Bus: 'B08' (PQ bus)
V8 = 0.8656715,
A8 = 11.8094897,

// Bus: 'B09' (PQ bus)
V9 = 0.9539161,
A9 = -11.6711254,

// Bus: 'B10' (PQ bus)
V10 = 0.9811799,
A10 = -5.9411523,

// Bus: 'B11' (PQ bus)
V11 = 1.0119525,
A11 = -2.3670254

);
end PF_Bus_best_00016;