within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00003
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -79.5622944,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = -89.5241509,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 9.2424972,

// Bus: 'B05' (PQ bus)
V5 = 0.9812196,
A5 = -86.1180048,

// Bus: 'B06' (PQ bus)
V6 = 0.9156429,
A6 = 83.3092820,

// Bus: 'B07' (PQ bus)
V7 = 0.8482474,
A7 = 73.7048875,

// Bus: 'B08' (PQ bus)
V8 = 0.6986955,
A8 = 34.7195578,

// Bus: 'B09' (PQ bus)
V9 = 0.8936049,
A9 = -1.5924061,

// Bus: 'B10' (PQ bus)
V10 = 0.9497681,
A10 = 2.2560930,

// Bus: 'B11' (PQ bus)
V11 = 0.9971583,
A11 = 0.7447158

);
end PF_Bus_best_00003;