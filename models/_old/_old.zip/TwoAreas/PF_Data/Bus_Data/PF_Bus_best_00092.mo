within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00092
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 30.8393145,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 21.0672850,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -8.5568625,

// Bus: 'B05' (PQ bus)
V5 = 1.0059843,
A5 = 24.3730993,

// Bus: 'B06' (PQ bus)
V6 = 0.9769806,
A6 = 14.2757737,

// Bus: 'B07' (PQ bus)
V7 = 0.9589563,
A7 = 5.8440934,

// Bus: 'B08' (PQ bus)
V8 = 0.9450664,
A8 = -8.8850071,

// Bus: 'B09' (PQ bus)
V9 = 0.9731976,
A9 = -23.2721371,

// Bus: 'B10' (PQ bus)
V10 = 0.9859396,
A10 = -15.2863745,

// Bus: 'B11' (PQ bus)
V11 = 1.0104942,
A11 = -5.9947905

);
end PF_Bus_best_00092;