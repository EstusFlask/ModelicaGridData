within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00040
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 65.9273450,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 55.9966867,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 2.6915943,

// Bus: 'B05' (PQ bus)
V5 = 0.9965638,
A5 = 59.3997400,

// Bus: 'B06' (PQ bus)
V6 = 0.9538784,
A6 = 49.0398868,

// Bus: 'B07' (PQ bus)
V7 = 0.9175400,
A7 = 40.1293522,

// Bus: 'B08' (PQ bus)
V8 = 0.8585489,
A8 = 14.8470031,

// Bus: 'B09' (PQ bus)
V9 = 0.9527627,
A9 = -9.3190479,

// Bus: 'B10' (PQ bus)
V10 = 0.9811820,
A10 = -4.0706999,

// Bus: 'B11' (PQ bus)
V11 = 1.0118569,
A11 = -1.6426648

);
end PF_Bus_best_00040;