within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00057
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 71.2187319,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 61.2622137,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 4.7482948,

// Bus: 'B05' (PQ bus)
V5 = 0.9950711,
A5 = 64.6812923,

// Bus: 'B06' (PQ bus)
V6 = 0.9502204,
A6 = 54.2784998,

// Bus: 'B07' (PQ bus)
V7 = 0.9109935,
A7 = 45.2873177,

// Bus: 'B08' (PQ bus)
V8 = 0.8444768,
A8 = 18.6362074,

// Bus: 'B09' (PQ bus)
V9 = 0.9485482,
A9 = -6.7623408,

// Bus: 'B10' (PQ bus)
V10 = 0.9793659,
A10 = -2.0265980,

// Bus: 'B11' (PQ bus)
V11 = 1.0107341,
A11 = -0.8527862

);
end PF_Bus_best_00057;