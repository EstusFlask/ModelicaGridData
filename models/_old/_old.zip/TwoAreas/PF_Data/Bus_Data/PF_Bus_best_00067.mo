within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00067
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 29.7623735,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 19.9867245,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -9.6270534,

// Bus: 'B05' (PQ bus)
V5 = 1.0057641,
A5 = 23.2947367,

// Bus: 'B06' (PQ bus)
V6 = 0.9764404,
A6 = 13.1914379,

// Bus: 'B07' (PQ bus)
V7 = 0.9579864,
A7 = 4.7491294,

// Bus: 'B08' (PQ bus)
V8 = 0.9423080,
A8 = -10.1110224,

// Bus: 'B09' (PQ bus)
V9 = 0.9698317,
A9 = -24.6637514,

// Bus: 'B10' (PQ bus)
V10 = 0.9831321,
A10 = -16.3758717,

// Bus: 'B11' (PQ bus)
V11 = 1.0085724,
A11 = -6.4098266

);
end PF_Bus_best_00067;