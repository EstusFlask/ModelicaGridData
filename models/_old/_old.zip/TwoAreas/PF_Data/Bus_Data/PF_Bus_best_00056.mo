within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00056
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 52.2133708,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 42.3584166,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -1.3886428,

// Bus: 'B05' (PQ bus)
V5 = 1.0010020,
A5 = 45.7148333,

// Bus: 'B06' (PQ bus)
V6 = 0.9647590,
A6 = 35.4804574,

// Bus: 'B07' (PQ bus)
V7 = 0.9370313,
A7 = 26.8018156,

// Bus: 'B08' (PQ bus)
V8 = 0.9003157,
A8 = 5.8499415,

// Bus: 'B09' (PQ bus)
V9 = 0.9657757,
A9 = -14.3298335,

// Bus: 'B10' (PQ bus)
V10 = 0.9867096,
A10 = -8.1128790,

// Bus: 'B11' (PQ bus)
V11 = 1.0139513,
A11 = -3.2112403

);
end PF_Bus_best_00056;