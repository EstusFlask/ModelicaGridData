within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00047
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 59.1472196,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 49.2700957,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 1.8657684,

// Bus: 'B05' (PQ bus)
V5 = 0.9996916,
A5 = 52.6401267,

// Bus: 'B06' (PQ bus)
V6 = 0.9615458,
A6 = 42.3690403,

// Bus: 'B07' (PQ bus)
V7 = 0.9312723,
A7 = 33.6231321,

// Bus: 'B08' (PQ bus)
V8 = 0.8887026,
A8 = 11.2265679,

// Bus: 'B09' (PQ bus)
V9 = 0.9644627,
A9 = -10.2395990,

// Bus: 'B10' (PQ bus)
V10 = 0.9873317,
A10 = -4.8542115,

// Bus: 'B11' (PQ bus)
V11 = 1.0143846,
A11 = -1.9448155

);
end PF_Bus_best_00047;