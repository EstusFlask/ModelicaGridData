within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00071
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 52.5706879,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 42.7239248,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -0.4249329,

// Bus: 'B05' (PQ bus)
V5 = 1.0014885,
A5 = 46.0753204,

// Bus: 'B06' (PQ bus)
V6 = 0.9659520,
A6 = 35.8545006,

// Bus: 'B07' (PQ bus)
V7 = 0.9391699,
A7 = 27.2005782,

// Bus: 'B08' (PQ bus)
V8 = 0.9053729,
A8 = 6.6707872,

// Bus: 'B09' (PQ bus)
V9 = 0.9690498,
A9 = -13.0783550,

// Bus: 'B10' (PQ bus)
V10 = 0.9889598,
A10 = -7.1337992,

// Bus: 'B11' (PQ bus)
V11 = 1.0149874,
A11 = -2.8315647

);
end PF_Bus_best_00071;