within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00065
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 42.5963425,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 32.7813152,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -4.7407125,

// Bus: 'B05' (PQ bus)
V5 = 1.0033849,
A5 = 36.1133040,

// Bus: 'B06' (PQ bus)
V6 = 0.9706032,
A6 = 25.9449678,

// Bus: 'B07' (PQ bus)
V7 = 0.9475115,
A7 = 17.3861426,

// Bus: 'B08' (PQ bus)
V8 = 0.9219345,
A8 = -0.8396702,

// Bus: 'B09' (PQ bus)
V9 = 0.9701184,
A9 = -18.5053375,

// Bus: 'B10' (PQ bus)
V10 = 0.9871485,
A10 = -11.4619452,

// Bus: 'B11' (PQ bus)
V11 = 1.0131244,
A11 = -4.5128388

);
end PF_Bus_best_00065;