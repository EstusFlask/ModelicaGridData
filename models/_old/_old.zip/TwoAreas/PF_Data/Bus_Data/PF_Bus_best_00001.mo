within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00001
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -80.5756445,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 89.2719766,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 8.2195075,

// Bus: 'B05' (PQ bus)
V5 = 0.9804631,
A5 = -87.1901443,

// Bus: 'B06' (PQ bus)
V6 = 0.9142734,
A6 = 82.0352131,

// Bus: 'B07' (PQ bus)
V7 = 0.8465552,
A7 = 72.2338274,

// Bus: 'B08' (PQ bus)
V8 = 0.6972614,
A8 = 33.3950177,

// Bus: 'B09' (PQ bus)
V9 = 0.8927756,
A9 = -2.9092867,

// Bus: 'B10' (PQ bus)
V10 = 0.9492863,
A10 = 1.2290377,

// Bus: 'B11' (PQ bus)
V11 = 0.9974972,
A11 = 0.3545882

);
end PF_Bus_best_00001;