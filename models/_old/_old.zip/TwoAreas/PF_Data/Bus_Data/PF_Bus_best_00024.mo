within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00024
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 86.0734324,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 76.0011401,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 7.9166780,

// Bus: 'B05' (PQ bus)
V5 = 0.9885297,
A5 = 79.4925419,

// Bus: 'B06' (PQ bus)
V6 = 0.9341991,
A6 = 68.8970446,

// Bus: 'B07' (PQ bus)
V7 = 0.8823607,
A7 = 59.5356478,

// Bus: 'B08' (PQ bus)
V8 = 0.7806632,
A8 = 27.4020409,

// Bus: 'B09' (PQ bus)
V9 = 0.9246015,
A9 = -2.9829419,

// Bus: 'B10' (PQ bus)
V10 = 0.9666300,
A10 = 1.0520958,

// Bus: 'B11' (PQ bus)
V11 = 1.0044861,
A11 = 0.3164574

);
end PF_Bus_best_00024;