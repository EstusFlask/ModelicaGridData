within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00033
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 75.6440447,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 65.6450657,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 5.0130199,

// Bus: 'B05' (PQ bus)
V5 = 0.9926454,
A5 = 69.0905602,

// Bus: 'B06' (PQ bus)
V6 = 0.9442778,
A6 = 58.6171802,

// Bus: 'B07' (PQ bus)
V7 = 0.9003653,
A7 = 49.4919710,

// Bus: 'B08' (PQ bus)
V8 = 0.8207882,
A8 = 20.7814921,

// Bus: 'B09' (PQ bus)
V9 = 0.9391502,
A9 = -6.5214054,

// Bus: 'B10' (PQ bus)
V10 = 0.9742773,
A10 = -1.7974249,

// Bus: 'B11' (PQ bus)
V11 = 1.0086398,
A11 = -0.7689957

);
end PF_Bus_best_00033;