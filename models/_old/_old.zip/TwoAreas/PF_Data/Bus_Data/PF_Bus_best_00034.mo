within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00034
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -81.9011256,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 88.0834114,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 7.3951360,

// Bus: 'B05' (PQ bus)
V5 = 0.9810359,
A5 = -88.4733593,

// Bus: 'B06' (PQ bus)
V6 = 0.9153288,
A6 = 80.8974667,

// Bus: 'B07' (PQ bus)
V7 = 0.8478986,
A7 = 71.2390310,

// Bus: 'B08' (PQ bus)
V8 = 0.6983922,
A8 = 32.3389425,

// Bus: 'B09' (PQ bus)
V9 = 0.8928734,
A9 = -3.9616225,

// Bus: 'B10' (PQ bus)
V10 = 0.9493224,
A10 = 0.4051405,

// Bus: 'B11' (PQ bus)
V11 = 0.9979095,
A11 = 0.0422848

);
end PF_Bus_best_00034;