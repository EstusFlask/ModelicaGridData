within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00026
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -78.1689270,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = -88.2136693,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 10.1957479,

// Bus: 'B05' (PQ bus)
V5 = 0.9808680,
A5 = -84.7502589,

// Bus: 'B06' (PQ bus)
V6 = 0.9149895,
A6 = 84.5889078,

// Bus: 'B07' (PQ bus)
V7 = 0.8474050,
A7 = 74.8977633,

// Bus: 'B08' (PQ bus)
V8 = 0.6979133,
A8 = 35.9438955,

// Bus: 'B09' (PQ bus)
V9 = 0.8934722,
A9 = -0.3772642,

// Bus: 'B10' (PQ bus)
V10 = 0.9496317,
A10 = 3.2082027,

// Bus: 'B11' (PQ bus)
V11 = 0.9965207,
A11 = 1.1052426

);
end PF_Bus_best_00026;