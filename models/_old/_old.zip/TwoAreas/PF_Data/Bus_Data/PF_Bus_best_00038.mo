within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00038
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -79.5319126,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = -89.2456869,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 9.5962068,

// Bus: 'B05' (PQ bus)
V5 = 0.9821966,
A5 = -86.0108479,

// Bus: 'B06' (PQ bus)
V6 = 0.9174236,
A6 = 83.6792378,

// Bus: 'B07' (PQ bus)
V7 = 0.8504713,
A7 = 74.3307310,

// Bus: 'B08' (PQ bus)
V8 = 0.7006156,
A8 = 35.1814230,

// Bus: 'B09' (PQ bus)
V9 = 0.8944040,
A9 = -1.1308753,

// Bus: 'B10' (PQ bus)
V10 = 0.9502304,
A10 = 2.6139086,

// Bus: 'B11' (PQ bus)
V11 = 0.9971564,
A11 = 0.8812084

);
end PF_Bus_best_00038;