within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00083
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 71.9194906,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 61.9651601,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 5.4517375,

// Bus: 'B05' (PQ bus)
V5 = 0.9951969,
A5 = 65.3828811,

// Bus: 'B06' (PQ bus)
V6 = 0.9505288,
A6 = 54.9837229,

// Bus: 'B07' (PQ bus)
V7 = 0.9115452,
A7 = 45.9993924,

// Bus: 'B08' (PQ bus)
V8 = 0.8458381,
A8 = 19.4380146,

// Bus: 'B09' (PQ bus)
V9 = 0.9495173,
A9 = -5.8638818,

// Bus: 'B10' (PQ bus)
V10 = 0.9800124,
A10 = -1.3186646,

// Bus: 'B11' (PQ bus)
V11 = 1.0107833,
A11 = -0.5783419

);
end PF_Bus_best_00083;