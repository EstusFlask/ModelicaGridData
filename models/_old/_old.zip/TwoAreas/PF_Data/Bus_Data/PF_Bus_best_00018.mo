within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00018
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 38.0973704,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 28.2976270,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -6.4292402,

// Bus: 'B05' (PQ bus)
V5 = 1.0043049,
A5 = 31.6202960,

// Bus: 'B06' (PQ bus)
V6 = 0.9728601,
A6 = 21.4772141,

// Bus: 'B07' (PQ bus)
V7 = 0.9515606,
A7 = 12.9638066,

// Bus: 'B08' (PQ bus)
V8 = 0.9299909,
A8 = -4.0643999,

// Bus: 'B09' (PQ bus)
V9 = 0.9707126,
A9 = -20.6254038,

// Bus: 'B10' (PQ bus)
V10 = 0.9862791,
A10 = -13.1564248,

// Bus: 'B11' (PQ bus)
V11 = 1.0119578,
A11 = -5.1693422

);
end PF_Bus_best_00018;