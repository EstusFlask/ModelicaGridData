within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00060
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -77.6199240,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = -87.2493662,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 11.1727380,

// Bus: 'B05' (PQ bus)
V5 = 0.9824952,
A5 = -84.0727456,

// Bus: 'B06' (PQ bus)
V6 = 0.9179503,
A6 = 85.7062786,

// Bus: 'B07' (PQ bus)
V7 = 0.8510918,
A7 = 76.4432153,

// Bus: 'B08' (PQ bus)
V8 = 0.7010192,
A8 = 37.2111136,

// Bus: 'B09' (PQ bus)
V9 = 0.8947009,
A9 = 0.8845865,

// Bus: 'B10' (PQ bus)
V10 = 0.9502656,
A10 = 4.1913117,

// Bus: 'B11' (PQ bus)
V11 = 0.9961484,
A11 = 1.4790289

);
end PF_Bus_best_00060;