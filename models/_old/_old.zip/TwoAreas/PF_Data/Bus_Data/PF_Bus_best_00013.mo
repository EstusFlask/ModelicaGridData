within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00013
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -83.6993542,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 86.4469708,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 6.2492216,

// Bus: 'B05' (PQ bus)
V5 = 0.9817053,
A5 = 89.7784564,

// Bus: 'B06' (PQ bus)
V6 = 0.9165650,
A6 = 79.3210540,

// Bus: 'B07' (PQ bus)
V7 = 0.8494771,
A7 = 69.8310044,

// Bus: 'B08' (PQ bus)
V8 = 0.6996846,
A8 = 30.8688603,

// Bus: 'B09' (PQ bus)
V9 = 0.8927752,
A9 = -5.4283676,

// Bus: 'B10' (PQ bus)
V10 = 0.9491810,
A10 = -0.7417244,

// Bus: 'B11' (PQ bus)
V11 = 0.9983238,
A11 = -0.3928026

);
end PF_Bus_best_00013;