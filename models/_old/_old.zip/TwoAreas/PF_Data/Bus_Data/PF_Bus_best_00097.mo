within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00097
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 67.1457394,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 57.2191291,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 3.9287480,

// Bus: 'B05' (PQ bus)
V5 = 0.9967985,
A5 = 60.6196782,

// Bus: 'B06' (PQ bus)
V6 = 0.9544537,
A6 = 50.2665430,

// Bus: 'B07' (PQ bus)
V7 = 0.9185698,
A7 = 41.3685660,

// Bus: 'B08' (PQ bus)
V8 = 0.8611377,
A8 = 16.2492805,

// Bus: 'B09' (PQ bus)
V9 = 0.9547856,
A9 = -7.7354151,

// Bus: 'B10' (PQ bus)
V10 = 0.9826076,
A10 = -2.8236895,

// Bus: 'B11' (PQ bus)
V11 = 1.0122196,
A11 = -1.1587918

);
end PF_Bus_best_00097;