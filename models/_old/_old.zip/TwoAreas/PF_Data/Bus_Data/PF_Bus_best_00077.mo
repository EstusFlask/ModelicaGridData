within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00077
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 67.2448795,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 57.3158296,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 3.8144923,

// Bus: 'B05' (PQ bus)
V5 = 0.9966570,
A5 = 60.7178878,

// Bus: 'B06' (PQ bus)
V6 = 0.9541069,
A6 = 50.3607038,

// Bus: 'B07' (PQ bus)
V7 = 0.9179490,
A7 = 41.4551605,

// Bus: 'B08' (PQ bus)
V8 = 0.8597348,
A8 = 16.2144978,

// Bus: 'B09' (PQ bus)
V9 = 0.9541302,
A9 = -7.8863000,

// Bus: 'B10' (PQ bus)
V10 = 0.9822231,
A10 = -2.9406007,

// Bus: 'B11' (PQ bus)
V11 = 1.0120903,
A11 = -1.2043582

);
end PF_Bus_best_00077;