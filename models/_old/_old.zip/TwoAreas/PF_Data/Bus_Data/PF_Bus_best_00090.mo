within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00090
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 27.1465935,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 17.3823459,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -10.1288816,

// Bus: 'B05' (PQ bus)
V5 = 1.0064585,
A5 = 20.6834378,

// Bus: 'B06' (PQ bus)
V6 = 0.9781442,
A6 = 10.5989516,

// Bus: 'B07' (PQ bus)
V7 = 0.9610453,
A7 = 2.1900749,

// Bus: 'B08' (PQ bus)
V8 = 0.9487225,
A8 = -11.6783442,

// Bus: 'B09' (PQ bus)
V9 = 0.9715421,
A9 = -25.2720588,

// Bus: 'B10' (PQ bus)
V10 = 0.9836149,
A10 = -16.8743722,

// Bus: 'B11' (PQ bus)
V11 = 1.0083660,
A11 = -6.6039362

);
end PF_Bus_best_00090;