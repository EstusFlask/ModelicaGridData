within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00096
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 58.9378321,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 49.0671163,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 2.2451725,

// Bus: 'B05' (PQ bus)
V5 = 1.0000695,
A5 = 52.4332084,

// Bus: 'B06' (PQ bus)
V6 = 0.9624723,
A6 = 42.1727362,

// Bus: 'B07' (PQ bus)
V7 = 0.9329325,
A7 = 33.4463259,

// Bus: 'B08' (PQ bus)
V8 = 0.8924647,
A8 = 11.3918763,

// Bus: 'B09' (PQ bus)
V9 = 0.9663591,
A9 = -9.7417189,

// Bus: 'B10' (PQ bus)
V10 = 0.9884906,
A10 = -4.4668928,

// Bus: 'B11' (PQ bus)
V11 = 1.0148176,
A11 = -1.7939002

);
end PF_Bus_best_00096;