within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00042
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 34.1032290,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 24.3150007,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -8.0202315,

// Bus: 'B05' (PQ bus)
V5 = 1.0050009,
A5 = 27.6306596,

// Bus: 'B06' (PQ bus)
V6 = 0.9745677,
A6 = 17.5065951,

// Bus: 'B07' (PQ bus)
V7 = 0.9546251,
A7 = 9.0272430,

// Bus: 'B08' (PQ bus)
V8 = 0.9358611,
A8 = -6.9972224,

// Bus: 'B09' (PQ bus)
V9 = 0.9702869,
A9 = -22.6346905,

// Bus: 'B10' (PQ bus)
V10 = 0.9847848,
A10 = -14.7576716,

// Bus: 'B11' (PQ bus)
V11 = 1.0103958,
A11 = -5.7872807

);
end PF_Bus_best_00042;