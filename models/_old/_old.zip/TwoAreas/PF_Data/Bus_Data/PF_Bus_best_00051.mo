within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00051
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 82.4468083,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 72.4048235,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 7.2051949,

// Bus: 'B05' (PQ bus)
V5 = 0.9902201,
A5 = 75.8772021,

// Bus: 'B06' (PQ bus)
V6 = 0.9383380,
A6 = 65.3322241,

// Bus: 'B07' (PQ bus)
V7 = 0.8897513,
A7 = 56.0692062,

// Bus: 'B08' (PQ bus)
V8 = 0.7972907,
A8 = 25.3148771,

// Bus: 'B09' (PQ bus)
V9 = 0.9308953,
A9 = -3.8249910,

// Bus: 'B10' (PQ bus)
V10 = 0.9700310,
A10 = 0.3647952,

// Bus: 'B11' (PQ bus)
V11 = 1.0061612,
A11 = 0.0580082

);
end PF_Bus_best_00051;