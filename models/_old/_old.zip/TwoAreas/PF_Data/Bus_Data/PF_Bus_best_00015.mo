within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00015
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 79.2530861,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 69.2003087,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 3.9993426,

// Bus: 'B05' (PQ bus)
V5 = 0.9896164,
A5 = 72.6794542,

// Bus: 'B06' (PQ bus)
V6 = 0.9368597,
A6 = 62.1164919,

// Bus: 'B07' (PQ bus)
V7 = 0.8871110,
A7 = 52.8185611,

// Bus: 'B08' (PQ bus)
V8 = 0.7907069,
A8 = 21.6501217,

// Bus: 'B09' (PQ bus)
V9 = 0.9264339,
A9 = -7.9392534,

// Bus: 'B10' (PQ bus)
V10 = 0.9671167,
A10 = -2.8617685,

// Bus: 'B11' (PQ bus)
V11 = 1.0060431,
A11 = -1.1842774

);
end PF_Bus_best_00015;