within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00031
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 67.5035490,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 57.5627695,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 3.1097642,

// Bus: 'B05' (PQ bus)
V5 = 0.9959781,
A5 = 60.9720892,

// Bus: 'B06' (PQ bus)
V6 = 0.9524432,
A6 = 50.5954347,

// Bus: 'B07' (PQ bus)
V7 = 0.9149711,
A7 = 41.6534236,

// Bus: 'B08' (PQ bus)
V8 = 0.8529511,
A8 = 15.8413172,

// Bus: 'B09' (PQ bus)
V9 = 0.9508189,
A9 = -8.8106638,

// Bus: 'B10' (PQ bus)
V10 = 0.9802353,
A10 = -3.6590916,

// Bus: 'B11' (PQ bus)
V11 = 1.0114233,
A11 = -1.4837421

);
end PF_Bus_best_00031;