within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00059
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -78.4363878,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = -88.1891424,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 10.3813901,

// Bus: 'B05' (PQ bus)
V5 = 0.9820296,
A5 = -84.9274211,

// Bus: 'B06' (PQ bus)
V6 = 0.9171090,
A6 = 84.7212192,

// Bus: 'B07' (PQ bus)
V7 = 0.8500572,
A7 = 75.3319243,

// Bus: 'B08' (PQ bus)
V8 = 0.7001947,
A8 = 36.1909060,

// Bus: 'B09' (PQ bus)
V9 = 0.8943513,
A9 = -0.1293837,

// Bus: 'B10' (PQ bus)
V10 = 0.9501419,
A10 = 3.3984899,

// Bus: 'B11' (PQ bus)
V11 = 0.9966276,
A11 = 1.1783906

);
end PF_Bus_best_00059;