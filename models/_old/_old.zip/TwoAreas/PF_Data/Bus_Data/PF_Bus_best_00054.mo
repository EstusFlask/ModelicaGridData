within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00054
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 66.2644947,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 56.3355793,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 3.0808199,

// Bus: 'B05' (PQ bus)
V5 = 0.9966648,
A5 = 59.7375543,

// Bus: 'B06' (PQ bus)
V6 = 0.9541260,
A6 = 49.3805935,

// Bus: 'B07' (PQ bus)
V7 = 0.9179832,
A7 = 40.4754677,

// Bus: 'B08' (PQ bus)
V8 = 0.8596341,
A8 = 15.2675040,

// Bus: 'B09' (PQ bus)
V9 = 0.9535288,
A9 = -8.8192368,

// Bus: 'B10' (PQ bus)
V10 = 0.9817103,
A10 = -3.6778184,

// Bus: 'B11' (PQ bus)
V11 = 1.0120151,
A11 = -1.4902642

);
end PF_Bus_best_00054;