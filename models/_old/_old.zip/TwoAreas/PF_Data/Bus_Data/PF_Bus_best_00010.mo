within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00010
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -83.0180414,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 86.8060197,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 6.3411511,

// Bus: 'B05' (PQ bus)
V5 = 0.9803984,
A5 = -89.6397682,

// Bus: 'B06' (PQ bus)
V6 = 0.9141770,
A6 = 79.5609771,

// Bus: 'B07' (PQ bus)
V7 = 0.8464792,
A7 = 69.7366276,

// Bus: 'B08' (PQ bus)
V8 = 0.6971061,
A8 = 30.9739679,

// Bus: 'B09' (PQ bus)
V9 = 0.8918555,
A9 = -5.3220415,

// Bus: 'B10' (PQ bus)
V10 = 0.9486376,
A10 = -0.6542110,

// Bus: 'B11' (PQ bus)
V11 = 0.9980454,
A11 = -0.3602414

);
end PF_Bus_best_00010;