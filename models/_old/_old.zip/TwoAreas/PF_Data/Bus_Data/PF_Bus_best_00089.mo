within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00089
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 35.5603810,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 25.7770576,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -6.5605793,

// Bus: 'B05' (PQ bus)
V5 = 1.0052981,
A5 = 29.0897336,

// Bus: 'B06' (PQ bus)
V6 = 0.9752970,
A6 = 18.9737670,

// Bus: 'B07' (PQ bus)
V7 = 0.9559340,
A7 = 10.5088784,

// Bus: 'B08' (PQ bus)
V8 = 0.9395208,
A8 = -5.3327232,

// Bus: 'B09' (PQ bus)
V9 = 0.9745551,
A9 = -20.7425570,

// Bus: 'B10' (PQ bus)
V10 = 0.9882990,
A10 = -13.2739517,

// Bus: 'B11' (PQ bus)
V11 = 1.0126973,
A11 = -5.2186295

);
end PF_Bus_best_00089;