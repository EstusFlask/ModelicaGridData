within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00073
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 66.3859674,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 56.4659832,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 3.8690114,

// Bus: 'B05' (PQ bus)
V5 = 0.9971833,
A5 = 59.8624358,

// Bus: 'B06' (PQ bus)
V6 = 0.9553969,
A6 = 49.5202949,

// Bus: 'B07' (PQ bus)
V7 = 0.9202585,
A7 = 40.6428342,

// Bus: 'B08' (PQ bus)
V8 = 0.8648675,
A8 = 15.8675557,

// Bus: 'B09' (PQ bus)
V9 = 0.9562696,
A9 = -7.7959427,

// Bus: 'B10' (PQ bus)
V10 = 0.9834055,
A10 = -2.8779219,

// Bus: 'B11' (PQ bus)
V11 = 1.0125495,
A11 = -1.1792636

);
end PF_Bus_best_00073;