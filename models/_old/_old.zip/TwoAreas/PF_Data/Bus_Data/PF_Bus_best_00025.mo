within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00025
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -78.7913257,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = -88.9413465,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 9.5803945,

// Bus: 'B05' (PQ bus)
V5 = 0.9804492,
A5 = -85.4051247,

// Bus: 'B06' (PQ bus)
V6 = 0.9142322,
A6 = 83.8224434,

// Bus: 'B07' (PQ bus)
V7 = 0.8464707,
A7 = 74.0223701,

// Bus: 'B08' (PQ bus)
V8 = 0.6971572,
A8 = 35.1476592,

// Bus: 'B09' (PQ bus)
V9 = 0.8930984,
A9 = -1.1673223,

// Bus: 'B10' (PQ bus)
V10 = 0.9494493,
A10 = 2.5911799,

// Bus: 'B11' (PQ bus)
V11 = 0.9968189,
A11 = 0.8711099

);
end PF_Bus_best_00025;