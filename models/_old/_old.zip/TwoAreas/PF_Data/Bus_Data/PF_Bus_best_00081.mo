within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00081
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 50.2505222,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 40.4159159,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -1.0486428,

// Bus: 'B05' (PQ bus)
V5 = 1.0022127,
A5 = 43.7598688,

// Bus: 'B06' (PQ bus)
V6 = 0.9677282,
A6 = 33.5591608,

// Bus: 'B07' (PQ bus)
V7 = 0.9423548,
A7 = 24.9417935,

// Bus: 'B08' (PQ bus)
V8 = 0.9121513,
A8 = 5.1854937,

// Bus: 'B09' (PQ bus)
V9 = 0.9711577,
A9 = -13.8410545,

// Bus: 'B10' (PQ bus)
V10 = 0.9898290,
A10 = -7.7515904,

// Bus: 'B11' (PQ bus)
V11 = 1.0152559,
A11 = -3.0723873

);
end PF_Bus_best_00081;