within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00078
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 58.0707220,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 48.1912853,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 0.8722091,

// Bus: 'B05' (PQ bus)
V5 = 0.9995554,
A5 = 51.5627387,

// Bus: 'B06' (PQ bus)
V6 = 0.9612119,
A6 = 41.2878210,

// Bus: 'B07' (PQ bus)
V7 = 0.9306740,
A7 = 32.5348653,

// Bus: 'B08' (PQ bus)
V8 = 0.8870876,
A8 = 10.0575158,

// Bus: 'B09' (PQ bus)
V9 = 0.9628327,
A9 = -11.5100258,

// Bus: 'B10' (PQ bus)
V10 = 0.9860866,
A10 = -5.8562947,

// Bus: 'B11' (PQ bus)
V11 = 1.0139135,
A11 = -2.3343351

);
end PF_Bus_best_00078;