within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00080
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 40.4277072,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 30.6227748,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -5.3158362,

// Bus: 'B05' (PQ bus)
V5 = 1.0039920,
A5 = 33.9486060,

// Bus: 'B06' (PQ bus)
V6 = 0.9720927,
A6 = 23.7969518,

// Bus: 'B07' (PQ bus)
V7 = 0.9501836,
A7 = 15.2681525,

// Bus: 'B08' (PQ bus)
V8 = 0.9275273,
A8 = -2.2312059,

// Bus: 'B09' (PQ bus)
V9 = 0.9715639,
A9 = -19.2123212,

// Bus: 'B10' (PQ bus)
V10 = 0.9875533,
A10 = -12.0343013,

// Bus: 'B11' (PQ bus)
V11 = 1.0130321,
A11 = -4.7357680

);
end PF_Bus_best_00080;