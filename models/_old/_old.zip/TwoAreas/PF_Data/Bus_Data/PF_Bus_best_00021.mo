within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00021
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 52.1315185,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 42.2807839,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -1.0882640,

// Bus: 'B05' (PQ bus)
V5 = 1.0012525,
A5 = 45.6346134,

// Bus: 'B06' (PQ bus)
V6 = 0.9653732,
A6 = 35.4072214,

// Bus: 'B07' (PQ bus)
V7 = 0.9381323,
A7 = 26.7413226,

// Bus: 'B08' (PQ bus)
V8 = 0.9028526,
A8 = 6.0177888,

// Bus: 'B09' (PQ bus)
V9 = 0.9672103,
A9 = -13.9348988,

// Bus: 'B10' (PQ bus)
V10 = 0.9876437,
A10 = -7.8061110,

// Bus: 'B11' (PQ bus)
V11 = 1.0143749,
A11 = -3.0925124

);
end PF_Bus_best_00021;