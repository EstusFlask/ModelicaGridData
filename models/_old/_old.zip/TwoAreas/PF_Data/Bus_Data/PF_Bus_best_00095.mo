within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00095
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 50.4072590,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 40.5774230,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -0.5074887,

// Bus: 'B05' (PQ bus)
V5 = 1.0024977,
A5 = 43.9184583,

// Bus: 'B06' (PQ bus)
V6 = 0.9684270,
A6 = 33.7256396,

// Bus: 'B07' (PQ bus)
V7 = 0.9436081,
A7 = 25.1225733,

// Bus: 'B08' (PQ bus)
V8 = 0.9150940,
A8 = 5.6254340,

// Bus: 'B09' (PQ bus)
V9 = 0.9730279,
A9 = -13.1389398,

// Bus: 'B10' (PQ bus)
V10 = 0.9911050,
A10 = -7.2017674,

// Bus: 'B11' (PQ bus)
V11 = 1.0158368,
A11 = -2.8587814

);
end PF_Bus_best_00095;