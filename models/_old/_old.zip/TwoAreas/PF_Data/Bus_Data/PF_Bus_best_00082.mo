within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00082
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 63.9550264,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 54.0521860,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 3.3856296,

// Bus: 'B05' (PQ bus)
V5 = 0.9981827,
A5 = 57.4380542,

// Bus: 'B06' (PQ bus)
V6 = 0.9578465,
A6 = 47.1243477,

// Bus: 'B07' (PQ bus)
V7 = 0.9246451,
A7 = 38.2997469,

// Bus: 'B08' (PQ bus)
V8 = 0.8744645,
A8 = 14.4418387,

// Bus: 'B09' (PQ bus)
V9 = 0.9598529,
A9 = -8.3699089,

// Bus: 'B10' (PQ bus)
V10 = 0.9852494,
A10 = -3.3486183,

// Bus: 'B11' (PQ bus)
V11 = 1.0133753,
A11 = -1.3607271

);
end PF_Bus_best_00082;