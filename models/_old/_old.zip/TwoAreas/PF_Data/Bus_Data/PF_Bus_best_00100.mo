within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00100
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 72.7807024,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 62.8135365,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 5.1477039,

// Bus: 'B05' (PQ bus)
V5 = 0.9944599,
A5 = 66.2392273,

// Bus: 'B06' (PQ bus)
V6 = 0.9487229,
A6 = 55.8187436,

// Bus: 'B07' (PQ bus)
V7 = 0.9083143,
A7 = 46.7941406,

// Bus: 'B08' (PQ bus)
V8 = 0.8385852,
A8 = 19.6088450,

// Bus: 'B09' (PQ bus)
V9 = 0.9464058,
A9 = -6.2786233,

// Bus: 'B10' (PQ bus)
V10 = 0.9782651,
A10 = -1.6348481,

// Bus: 'B11' (PQ bus)
V11 = 1.0101838,
A11 = -0.7023806

);
end PF_Bus_best_00100;