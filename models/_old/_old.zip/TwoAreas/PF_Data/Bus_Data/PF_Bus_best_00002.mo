within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00002
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -80.0495656,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 89.9221286,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 8.7832966,

// Bus: 'B05' (PQ bus)
V5 = 0.9809596,
A5 = -86.6257938,

// Bus: 'B06' (PQ bus)
V6 = 0.9151733,
A6 = 82.7311133,

// Bus: 'B07' (PQ bus)
V7 = 0.8476699,
A7 = 73.0582071,

// Bus: 'B08' (PQ bus)
V8 = 0.6982116,
A8 = 34.1260535,

// Bus: 'B09' (PQ bus)
V9 = 0.8933074,
A9 = -2.1825057,

// Bus: 'B10' (PQ bus)
V10 = 0.9496026,
A10 = 1.7954666,

// Bus: 'B11' (PQ bus)
V11 = 0.9973415,
A11 = 0.5698241

);
end PF_Bus_best_00002;