within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00008
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 77.4477601,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 67.4234802,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 4.5950321,

// Bus: 'B05' (PQ bus)
V5 = 0.9912148,
A5 = 70.8847753,

// Bus: 'B06' (PQ bus)
V6 = 0.9407738,
A6 = 60.3692858,

// Bus: 'B07' (PQ bus)
V7 = 0.8941028,
A7 = 51.1632549,

// Bus: 'B08' (PQ bus)
V8 = 0.8066314,
A8 = 21.2809313,

// Bus: 'B09' (PQ bus)
V9 = 0.9332069,
A9 = -7.1118302,

// Bus: 'B10' (PQ bus)
V10 = 0.9709501,
A10 = -2.2388610,

// Bus: 'B11' (PQ bus)
V11 = 1.0074305,
A11 = -0.9419756

);
end PF_Bus_best_00008;