within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00050
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 80.1920054,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 70.1691254,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 6.8076838,

// Bus: 'B05' (PQ bus)
V5 = 0.9912937,
A5 = 73.6295451,

// Bus: 'B06' (PQ bus)
V6 = 0.9409670,
A6 = 63.1163865,

// Bus: 'B07' (PQ bus)
V7 = 0.8944479,
A7 = 53.9148463,

// Bus: 'B08' (PQ bus)
V8 = 0.8078138,
A8 = 24.0457301,

// Bus: 'B09' (PQ bus)
V9 = 0.9349076,
A9 = -4.2900574,

// Bus: 'B10' (PQ bus)
V10 = 0.9721917,
A10 = -0.0174409,

// Bus: 'B11' (PQ bus)
V11 = 1.0071859,
A11 = -0.0858743

);
end PF_Bus_best_00050;