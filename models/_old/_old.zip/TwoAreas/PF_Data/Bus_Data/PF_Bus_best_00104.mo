within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00104
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 44.2601552,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 34.4377730,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -4.2399736,

// Bus: 'B05' (PQ bus)
V5 = 1.0029437,
A5 = 37.7742528,

// Bus: 'B06' (PQ bus)
V6 = 0.9695211,
A6 = 27.5937588,

// Bus: 'B07' (PQ bus)
V7 = 0.9455704,
A7 = 19.0129899,

// Bus: 'B08' (PQ bus)
V8 = 0.9179025,
A8 = 0.2666548,

// Bus: 'B09' (PQ bus)
V9 = 0.9691937,
A9 = -17.8854135,

// Bus: 'B10' (PQ bus)
V10 = 0.9869667,
A10 = -10.9624498,

// Bus: 'B11' (PQ bus)
V11 = 1.0132536,
A11 = -4.3185716

);
end PF_Bus_best_00104;