within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00101
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 70.0733983,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 60.1229730,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 4.3325681,

// Bus: 'B05' (PQ bus)
V5 = 0.9954217,
A5 = 63.5382716,

// Bus: 'B06' (PQ bus)
V6 = 0.9510797,
A6 = 53.1455997,

// Bus: 'B07' (PQ bus)
V7 = 0.9125309,
A7 = 44.1734857,

// Bus: 'B08' (PQ bus)
V8 = 0.8478121,
A8 = 17.8369545,

// Bus: 'B09' (PQ bus)
V9 = 0.9496311,
A9 = -7.2770036,

// Bus: 'B10' (PQ bus)
V10 = 0.9798765,
A10 = -2.4387779,

// Bus: 'B11' (PQ bus)
V11 = 1.0110426,
A11 = -1.0117851

);
end PF_Bus_best_00101;