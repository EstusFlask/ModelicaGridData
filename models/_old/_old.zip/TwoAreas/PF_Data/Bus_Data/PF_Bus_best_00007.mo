within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00007
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 83.0566369,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 72.9830149,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 5.4915703,

// Bus: 'B05' (PQ bus)
V5 = 0.9884558,
A5 = 76.4752528,

// Bus: 'B06' (PQ bus)
V6 = 0.9340184,
A6 = 65.8775377,

// Bus: 'B07' (PQ bus)
V7 = 0.8820381,
A7 = 56.5118004,

// Bus: 'B08' (PQ bus)
V8 = 0.7795517,
A8 = 24.3643928,

// Bus: 'B09' (PQ bus)
V9 = 0.9230430,
A9 = -6.0780946,

// Bus: 'B10' (PQ bus)
V10 = 0.9655539,
A10 = -1.3806997,

// Bus: 'B11' (PQ bus)
V11 = 1.0050343,
A11 = -0.6175865

);
end PF_Bus_best_00007;