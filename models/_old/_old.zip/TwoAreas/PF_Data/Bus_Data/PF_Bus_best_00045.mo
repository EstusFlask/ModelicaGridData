within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00045
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 41.9770249,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 32.1706041,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -4.3781087,

// Bus: 'B05' (PQ bus)
V5 = 1.0039024,
A5 = 35.4973428,

// Bus: 'B06' (PQ bus)
V6 = 0.9718727,
A6 = 25.3432293,

// Bus: 'B07' (PQ bus)
V7 = 0.9497891,
A7 = 16.8100096,

// Bus: 'B08' (PQ bus)
V8 = 0.9271044,
A8 = -0.8797715,

// Bus: 'B09' (PQ bus)
V9 = 0.9728839,
A9 = -18.0152440,

// Bus: 'B10' (PQ bus)
V10 = 0.9889087,
A10 = -11.0873229,

// Bus: 'B11' (PQ bus)
V11 = 1.0139792,
A11 = -4.3695906

);
end PF_Bus_best_00045;