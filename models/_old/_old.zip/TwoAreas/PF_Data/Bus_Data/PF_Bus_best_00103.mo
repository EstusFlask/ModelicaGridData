within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00103
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 47.9417136,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 38.1045299,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -2.9391017,

// Bus: 'B05' (PQ bus)
V5 = 1.0020589,
A5 = 41.4500598,

// Bus: 'B06' (PQ bus)
V6 = 0.9673510,
A6 = 31.2450884,

// Bus: 'B07' (PQ bus)
V7 = 0.9416784,
A7 = 22.6199838,

// Bus: 'B08' (PQ bus)
V8 = 0.9099201,
A8 = 2.8413217,

// Bus: 'B09' (PQ bus)
V9 = 0.9677437,
A9 = -16.2625879,

// Bus: 'B10' (PQ bus)
V10 = 0.9869601,
A10 = -9.6616229,

// Bus: 'B11' (PQ bus)
V11 = 1.0136902,
A11 = -3.8132002

);
end PF_Bus_best_00103;