within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00030
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 88.0131818,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 77.9143111,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 7.6121516,

// Bus: 'B05' (PQ bus)
V5 = 0.9870597,
A5 = 81.4224476,

// Bus: 'B06' (PQ bus)
V6 = 0.9306009,
A6 = 70.7826050,

// Bus: 'B07' (PQ bus)
V7 = 0.8759395,
A7 = 61.3340668,

// Bus: 'B08' (PQ bus)
V8 = 0.7660320,
A8 = 28.0256688,

// Bus: 'B09' (PQ bus)
V9 = 0.9187810,
A9 = -3.4256540,

// Bus: 'B10' (PQ bus)
V10 = 0.9634428,
A10 = 0.7247506,

// Bus: 'B11' (PQ bus)
V11 = 1.0033726,
A11 = 0.1859357

);
end PF_Bus_best_00030;