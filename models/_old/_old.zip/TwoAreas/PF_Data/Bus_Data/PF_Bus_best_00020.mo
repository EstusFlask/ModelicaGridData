within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00020
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 45.9704212,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 36.1433389,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -3.4520343,

// Bus: 'B05' (PQ bus)
V5 = 1.0026623,
A5 = 39.4826907,

// Bus: 'B06' (PQ bus)
V6 = 0.9688309,
A6 = 29.2944257,

// Bus: 'B07' (PQ bus)
V7 = 0.9443325,
A7 = 20.6996038,

// Bus: 'B08' (PQ bus)
V8 = 0.9155352,
A8 = 1.5882719,

// Bus: 'B09' (PQ bus)
V9 = 0.9693768,
A9 = -16.8900738,

// Bus: 'B10' (PQ bus)
V10 = 0.9875566,
A10 = -10.1704768,

// Bus: 'B11' (PQ bus)
V11 = 1.0137711,
A11 = -4.0115421

);
end PF_Bus_best_00020;