within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00085
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 74.2641382,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 64.2998895,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 6.5107683,

// Bus: 'B05' (PQ bus)
V5 = 0.9946271,
A5 = 67.7237679,

// Bus: 'B06' (PQ bus)
V6 = 0.9491327,
A6 = 57.3081319,

// Bus: 'B07' (PQ bus)
V7 = 0.9090474,
A7 = 48.2926981,

// Bus: 'B08' (PQ bus)
V8 = 0.8404451,
A8 = 21.2191129,

// Bus: 'B09' (PQ bus)
V9 = 0.9478614,
A9 = -4.5419794,

// Bus: 'B10' (PQ bus)
V10 = 0.9792361,
A10 = -0.2650270,

// Bus: 'B11' (PQ bus)
V11 = 1.0100950,
A11 = -0.1718299

);
end PF_Bus_best_00085;