within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00079
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 43.8725786,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 34.0524895,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -4.3060400,

// Bus: 'B05' (PQ bus)
V5 = 1.0030812,
A5 = 37.3875686,

// Bus: 'B06' (PQ bus)
V6 = 0.9698582,
A6 = 27.2108657,

// Bus: 'B07' (PQ bus)
V7 = 0.9461751,
A7 = 18.6369449,

// Bus: 'B08' (PQ bus)
V8 = 0.9192011,
A8 = 0.0434077,

// Bus: 'B09' (PQ bus)
V9 = 0.9696420,
A9 = -17.9632981,

// Bus: 'B10' (PQ bus)
V10 = 0.9871710,
A10 = -11.0271187,

// Bus: 'B11' (PQ bus)
V11 = 1.0133099,
A11 = -4.3439533

);
end PF_Bus_best_00079;