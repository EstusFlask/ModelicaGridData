within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00099
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 72.4857120,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 62.5229347,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 5.2495430,

// Bus: 'B05' (PQ bus)
V5 = 0.9947115,
A5 = 65.9458992,

// Bus: 'B06' (PQ bus)
V6 = 0.9493395,
A6 = 55.5327080,

// Bus: 'B07' (PQ bus)
V7 = 0.9094175,
A7 = 46.5218952,

// Bus: 'B08' (PQ bus)
V8 = 0.8410633,
A8 = 19.5488957,

// Bus: 'B09' (PQ bus)
V9 = 0.9474684,
A9 = -6.1394124,

// Bus: 'B10' (PQ bus)
V10 = 0.9788621,
A10 = -1.5288527,

// Bus: 'B11' (PQ bus)
V11 = 1.0103901,
A11 = -0.6608160

);
end PF_Bus_best_00099;