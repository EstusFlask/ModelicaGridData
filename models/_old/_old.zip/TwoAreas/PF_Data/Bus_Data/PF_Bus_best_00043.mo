within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00043
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 33.6269627,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 23.8431914,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -7.9007336,

// Bus: 'B05' (PQ bus)
V5 = 1.0052710,
A5 = 27.1561397,

// Bus: 'B06' (PQ bus)
V6 = 0.9752304,
A6 = 17.0394338,

// Bus: 'B07' (PQ bus)
V7 = 0.9558144,
A7 = 8.5732257,

// Bus: 'B08' (PQ bus)
V8 = 0.9385399,
A8 = -7.1386995,

// Bus: 'B09' (PQ bus)
V9 = 0.9716674,
A9 = -22.4662800,

// Bus: 'B10' (PQ bus)
V10 = 0.9856461,
A10 = -14.6322586,

// Bus: 'B11' (PQ bus)
V11 = 1.0108208,
A11 = -5.7405407

);
end PF_Bus_best_00043;