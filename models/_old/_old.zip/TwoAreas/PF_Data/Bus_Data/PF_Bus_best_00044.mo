within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00044
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 36.8330376,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 27.0417770,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -6.4784499,

// Bus: 'B05' (PQ bus)
V5 = 1.0048174,
A5 = 30.3592810,

// Bus: 'B06' (PQ bus)
V6 = 0.9741174,
A6 = 20.2302094,

// Bus: 'B07' (PQ bus)
V7 = 0.9538170,
A7 = 11.7419030,

// Bus: 'B08' (PQ bus)
V8 = 0.9349191,
A8 = -4.6848177,

// Bus: 'B09' (PQ bus)
V9 = 0.9727323,
A9 = -20.6620080,

// Bus: 'B10' (PQ bus)
V10 = 0.9873558,
A10 = -13.1982648,

// Bus: 'B11' (PQ bus)
V11 = 1.0123636,
A11 = -5.1875216

);
end PF_Bus_best_00044;