within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00074
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 69.0543277,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 59.1167295,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 4.5336561,

// Bus: 'B05' (PQ bus)
V5 = 0.9961620,
A5 = 62.5240788,

// Bus: 'B06' (PQ bus)
V6 = 0.9528938,
A6 = 52.1527059,

// Bus: 'B07' (PQ bus)
V7 = 0.9157776,
A7 = 43.2206006,

// Bus: 'B08' (PQ bus)
V8 = 0.8550711,
A8 = 17.5221548,

// Bus: 'B09' (PQ bus)
V9 = 0.9527192,
A9 = -6.9921258,

// Bus: 'B10' (PQ bus)
V10 = 0.9816048,
A10 = -2.2257116,

// Bus: 'B11' (PQ bus)
V11 = 1.0116799,
A11 = -0.9279002

);
end PF_Bus_best_00074;