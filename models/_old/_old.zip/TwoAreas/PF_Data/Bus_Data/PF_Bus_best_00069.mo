within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00069
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 36.2017808,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 26.4124705,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -6.7166789,

// Bus: 'B05' (PQ bus)
V5 = 1.0049354,
A5 = 29.7287877,

// Bus: 'B06' (PQ bus)
V6 = 0.9744070,
A6 = 19.6029367,

// Bus: 'B07' (PQ bus)
V7 = 0.9543367,
A7 = 11.1203908,

// Bus: 'B08' (PQ bus)
V8 = 0.9359357,
A8 = -5.1393721,

// Bus: 'B09' (PQ bus)
V9 = 0.9727436,
A9 = -20.9618083,

// Bus: 'B10' (PQ bus)
V10 = 0.9871813,
A10 = -13.4376875,

// Bus: 'B11' (PQ bus)
V11 = 1.0121605,
A11 = -5.2801629

);
end PF_Bus_best_00069;