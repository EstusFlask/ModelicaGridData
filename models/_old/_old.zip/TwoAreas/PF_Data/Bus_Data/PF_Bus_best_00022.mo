within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00022
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 61.4997768,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 51.6039791,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 2.1007547,

// Bus: 'B05' (PQ bus)
V5 = 0.9985947,
A5 = 54.9855054,

// Bus: 'B06' (PQ bus)
V6 = 0.9588566,
A6 = 44.6834747,

// Bus: 'B07' (PQ bus)
V7 = 0.9264544,
A7 = 35.8804961,

// Bus: 'B08' (PQ bus)
V8 = 0.8781335,
A8 = 12.4507688,

// Bus: 'B09' (PQ bus)
V9 = 0.9603029,
A9 = -9.9865399,

// Bus: 'B10' (PQ bus)
V10 = 0.9851300,
A10 = -4.6343131,

// Bus: 'B11' (PQ bus)
V11 = 1.0134897,
A11 = -1.8599014

);
end PF_Bus_best_00022;