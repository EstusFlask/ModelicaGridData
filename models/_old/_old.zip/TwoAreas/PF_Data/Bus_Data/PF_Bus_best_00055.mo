within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00055
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 51.1368072,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 41.2845920,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -1.9365693,

// Bus: 'B05' (PQ bus)
V5 = 1.0011646,
A5 = 44.6393292,

// Bus: 'B06' (PQ bus)
V6 = 0.9651576,
A6 = 34.4094869,

// Bus: 'B07' (PQ bus)
V7 = 0.9377458,
A7 = 25.7391191,

// Bus: 'B08' (PQ bus)
V8 = 0.9016759,
A8 = 4.9850203,

// Bus: 'B09' (PQ bus)
V9 = 0.9656423,
A9 = -15.0225086,

// Bus: 'B10' (PQ bus)
V10 = 0.9863567,
A10 = -8.6632225,

// Bus: 'B11' (PQ bus)
V11 = 1.0137022,
A11 = -3.4248238

);
end PF_Bus_best_00055;