within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00053
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 78.0089471,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 67.9987628,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 6.0270061,

// Bus: 'B05' (PQ bus)
V5 = 0.9920105,
A5 = 71.4512496,

// Bus: 'B06' (PQ bus)
V6 = 0.9427226,
A6 = 60.9592246,

// Bus: 'B07' (PQ bus)
V7 = 0.8975853,
A7 = 51.7983099,

// Bus: 'B08' (PQ bus)
V8 = 0.8147411,
A8 = 22.5359861,

// Bus: 'B09' (PQ bus)
V9 = 0.9373025,
A9 = -5.2555239,

// Bus: 'B10' (PQ bus)
V10 = 0.9734189,
A10 = -0.7894732,

// Bus: 'B11' (PQ bus)
V11 = 1.0079733,
A11 = -0.3815239

);
end PF_Bus_best_00053;