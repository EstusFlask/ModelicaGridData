within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00072
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 60.9376576,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 51.0485895,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 2.2245062,

// Bus: 'B05' (PQ bus)
V5 = 0.9989893,
A5 = 54.4259702,

// Bus: 'B06' (PQ bus)
V6 = 0.9598239,
A6 = 44.1350936,

// Bus: 'B07' (PQ bus)
V7 = 0.9281872,
A7 = 35.3527254,

// Bus: 'B08' (PQ bus)
V8 = 0.8819951,
A8 = 12.2823522,

// Bus: 'B09' (PQ bus)
V9 = 0.9620078,
A9 = -9.8126635,

// Bus: 'B10' (PQ bus)
V10 = 0.9861023,
A10 = -4.5038903,

// Bus: 'B11' (PQ bus)
V11 = 1.0138671,
A11 = -1.8089867

);
end PF_Bus_best_00072;