within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00058
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = -79.6634696,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = -89.7451073,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 9.0064725,

// Bus: 'B05' (PQ bus)
V5 = 0.9807389,
A5 = -86.2561651,

// Bus: 'B06' (PQ bus)
V6 = 0.9147678,
A6 = 83.0441089,

// Bus: 'B07' (PQ bus)
V7 = 0.8471561,
A7 = 73.3156390,

// Bus: 'B08' (PQ bus)
V8 = 0.6977657,
A8 = 34.4113911,

// Bus: 'B09' (PQ bus)
V9 = 0.8931997,
A9 = -1.8988266,

// Bus: 'B10' (PQ bus)
V10 = 0.9495331,
A10 = 2.0180208,

// Bus: 'B11' (PQ bus)
V11 = 0.9971875,
A11 = 0.6540595

);
end PF_Bus_best_00058;