within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00106
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 71.1372789,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 61.1821623,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = 4.7916487,

// Bus: 'B05' (PQ bus)
V5 = 0.9951517,
A5 = 64.6003711,

// Bus: 'B06' (PQ bus)
V6 = 0.9504180,
A6 = 54.1999070,

// Bus: 'B07' (PQ bus)
V7 = 0.9113469,
A7 = 45.2131151,

// Bus: 'B08' (PQ bus)
V8 = 0.8452724,
A8 = 18.6301616,

// Bus: 'B09' (PQ bus)
V9 = 0.9488983,
A9 = -6.7040649,

// Bus: 'B10' (PQ bus)
V10 = 0.9795652,
A10 = -1.9818591,

// Bus: 'B11' (PQ bus)
V11 = 1.0108015,
A11 = -0.8353047

);
end PF_Bus_best_00106;