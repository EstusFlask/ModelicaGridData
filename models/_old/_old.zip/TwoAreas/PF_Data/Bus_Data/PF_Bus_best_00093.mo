within TwoAreas.PF_Data.Bus_Data;
record PF_Bus_best_00093
extends TwoAreas.PF_Data.Bus_Data.Bus_Template(

// Bus: 'B01' (PV bus)
V1 = 1.0300000,
A1 = 34.8150175,

// Bus: 'B02' (PV bus)
V2 = 1.0100000,
A2 = 25.0350161,

// Bus: 'B03' (slack bus)
V3 = 1.0300000,
A3 = 0.0000000,

// Bus: 'B04' (PV bus)
V4 = 1.0100000,
A4 = -6.7303076,

// Bus: 'B05' (PQ bus)
V5 = 1.0054997,
A5 = 28.3456727,

// Bus: 'B06' (PQ bus)
V6 = 0.9757916,
A6 = 18.2351901,

// Bus: 'B07' (PQ bus)
V7 = 0.9568218,
A7 = 9.7800834,

// Bus: 'B08' (PQ bus)
V8 = 0.9413797,
A8 = -5.7947975,

// Bus: 'B09' (PQ bus)
V9 = 0.9750488,
A9 = -20.9499654,

// Bus: 'B10' (PQ bus)
V10 = 0.9884423,
A10 = -13.4427024,

// Bus: 'B11' (PQ bus)
V11 = 1.0126596,
A11 = -5.2844586

);
end PF_Bus_best_00093;