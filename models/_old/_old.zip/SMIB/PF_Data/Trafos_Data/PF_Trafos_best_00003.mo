within SMIB.PF_Data.Trafos_Data;
record PF_Trafos_best_00003
extends SMIB.PF_Data.Trafos_Data.Trafos_Template(

);
end PF_Trafos_best_00003;