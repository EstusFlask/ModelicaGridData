within SMIB.PF_Data.Trafos_Data;
record PF_Trafos_best_00016
extends SMIB.PF_Data.Trafos_Data.Trafos_Template(

);
end PF_Trafos_best_00016;