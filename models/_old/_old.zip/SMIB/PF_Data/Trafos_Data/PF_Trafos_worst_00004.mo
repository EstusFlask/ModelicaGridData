within SMIB.PF_Data.Trafos_Data;
record PF_Trafos_worst_00004
extends SMIB.PF_Data.Trafos_Data.Trafos_Template(

);
end PF_Trafos_worst_00004;