within SevenBus.PF_Data.Machines_Data;
record PF_Machines_load_00021
extends SevenBus.PF_Data.Machines_Data.Machines_Template(

// MACHINE: '21_1'
// Bus: FSSVG'
PG1 = (962.2000000),
QG1 = (200.0000001),

// MACHINE: '61_1'
// Bus: FVALDIG'
PG2 = (480.4280000),
QG2 = (170.8195819),

// MACHINE: '71_1'
// Bus: FVERGTG'
PG3 = (-98.2260829),
QG3 = (-232.2246625)

);
end PF_Machines_load_00021;