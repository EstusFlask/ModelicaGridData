within SevenBus.PF_Data.Machines_Data;
record PF_Machines_worst_00011
extends SevenBus.PF_Data.Machines_Data.Machines_Template(

// MACHINE: '21_1'
// Bus: FSSVG'
PG1 = (962.2000000),
QG1 = (200.0000001),

// MACHINE: '61_1'
// Bus: FVALDIG'
PG2 = (480.4280000),
QG2 = (169.9070692),

// MACHINE: '71_1'
// Bus: FVERGTG'
PG3 = (-261.0534862),
QG3 = (-226.7664831)

);
end PF_Machines_worst_00011;