within SevenBus.PF_Data.Machines_Data;
record PF_Machines_best_00004
extends SevenBus.PF_Data.Machines_Data.Machines_Template(

// MACHINE: '21_1'
// Bus: FSSVG'
PG1 = (962.2000000),
QG1 = (200.0000001),

// MACHINE: '61_1'
// Bus: FVALDIG'
PG2 = (480.4280000),
QG2 = (171.1542789),

// MACHINE: '71_1'
// Bus: FVERGTG'
PG3 = (-455.4587680),
QG3 = (-214.8504261)

);
end PF_Machines_best_00004;