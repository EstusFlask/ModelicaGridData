within SevenBus.PF_Data.Machines_Data;
record PF_Machines_best_00011
extends SevenBus.PF_Data.Machines_Data.Machines_Template(

// MACHINE: '21_1'
// Bus: FSSVG'
PG1 = (962.2000000),
QG1 = (200.0000001),

// MACHINE: '61_1'
// Bus: FVALDIG'
PG2 = (480.4280000),
QG2 = (169.9490981),

// MACHINE: '71_1'
// Bus: FVERGTG'
PG3 = (-302.6624540),
QG3 = (-224.7200462)

);
end PF_Machines_best_00011;